/**
 * Camada de regras do CONTROLE OPERACIONAL.
 *
 * Nenhum valor, jornada ou data é fixo aqui: tudo vem de `AppSettings`
 * (configuração global do administrador) ou de `Employee` (regra específica
 * do colaborador, que sempre prevalece sobre a global).
 *
 * A camada é pura (sem acesso a banco/rede) para permitir reuso futuro em
 * relatórios, exportações ou processamento no servidor.
 */

export type EmployeeType = "diarista" | "freelancer" | "mensalista" | "outro";
export type PeriodStatus = "aberto" | "fechado";
export type EntryStatus =
  | "em_andamento"
  | "finalizado"
  | "corrigido"
  | "aguardando_conferencia"
  | "aprovado";

export interface AppSettings {
  id: boolean;
  jornada_diaria_horas: number;
  jornada_semanal_horas: number;
  hora_inicio_prevista: string;
  hora_fim_prevista: string;
  tolerancia_minutos: number;
  valor_hora_extra: number;
  forma_calculo_hora_extra: string; // "valor_fixo" | "percentual_hora"
  percentual_hora_extra: number;
  noturno_inicio: string;
  noturno_fim: string;
  valor_hora_noturna: number;
  valor_vt: number;
  vt_padrao_ativo: boolean;
  adicional_padrao: number;
  desconto_padrao: number;
  outros_custos_padrao: number;
  intervalo_descontado: boolean;
}

export interface Employee {
  id: string;
  user_id: string | null;
  nome: string;
  documento: string | null;
  tipo: EmployeeType;
  valor_diaria: number | null;
  jornada_diaria_horas: number | null;
  valor_hora_extra: number | null;
  valor_hora_noturna: number | null;
  valor_vt: number | null;
  ativo: boolean;
  observacoes: string | null;
}

export interface TimeEntry {
  id: string;
  employee_id: string;
  data: string;
  entrada: string | null;
  intervalo_inicio: string | null;
  intervalo_fim: string | null;
  saida: string | null;
  horas_trabalhadas: number;
  jornada_prevista: number;
  horas_extras: number;
  horas_noturnas: number;
  horas_extras_manual: boolean;
  horas_noturnas_manual: boolean;
  vt_aplicado: boolean;
  vt_valor: number | null;
  adicionais: number;
  descontos: number;
  outros_custos: number;
  observacoes: string | null;
  status: EntryStatus;
}

export interface EffectiveRules {
  jornadaDiaria: number;
  valorDiaria: number;
  valorHoraExtra: number;
  valorHoraNoturna: number;
  valorVt: number;
}

const num = (v: unknown, fallback = 0): number => {
  const n = typeof v === "string" ? Number(v) : (v as number);
  return Number.isFinite(n) ? (n as number) : fallback;
};

/** Regra do colaborador prevalece; senão usa a configuração global. */
export function effectiveRules(employee: Employee, settings: AppSettings): EffectiveRules {
  const jornadaDiaria = num(employee.jornada_diaria_horas, num(settings.jornada_diaria_horas, 0));
  const valorDiaria = num(employee.valor_diaria, 0);

  let valorHoraExtra = employee.valor_hora_extra != null ? num(employee.valor_hora_extra) : NaN;
  if (!Number.isFinite(valorHoraExtra)) {
    if (settings.forma_calculo_hora_extra === "percentual_hora" && jornadaDiaria > 0) {
      const base = valorDiaria / jornadaDiaria;
      valorHoraExtra = base * (1 + num(settings.percentual_hora_extra) / 100);
    } else {
      valorHoraExtra = num(settings.valor_hora_extra);
    }
  }

  return {
    jornadaDiaria,
    valorDiaria,
    valorHoraExtra,
    valorHoraNoturna:
      employee.valor_hora_noturna != null
        ? num(employee.valor_hora_noturna)
        : num(settings.valor_hora_noturna),
    valorVt: employee.valor_vt != null ? num(employee.valor_vt) : num(settings.valor_vt),
  };
}

/** "22:00" | "22:00:00" -> minutos desde a meia-noite */
export function timeToMinutes(value: string | null | undefined): number {
  if (!value) return 0;
  const [h = "0", m = "0"] = value.split(":");
  return Number(h) * 60 + Number(m);
}

const HOUR = 3_600_000;

interface Interval {
  start: number;
  end: number;
}

/** Blocos efetivamente trabalhados (o intervalo nunca conta como trabalho). */
export function workedIntervals(entry: TimeEntry, descontarIntervalo = true): Interval[] {
  if (!entry.entrada || !entry.saida) return [];
  const start = new Date(entry.entrada).getTime();
  const end = new Date(entry.saida).getTime();
  if (!(end > start)) return [];

  const bStart = entry.intervalo_inicio ? new Date(entry.intervalo_inicio).getTime() : null;
  const bEnd = entry.intervalo_fim ? new Date(entry.intervalo_fim).getTime() : null;

  if (!descontarIntervalo || bStart == null || bEnd == null || bEnd <= bStart) {
    return [{ start, end }];
  }
  const cs = Math.max(start, Math.min(bStart, end));
  const ce = Math.max(start, Math.min(bEnd, end));
  const blocks: Interval[] = [];
  if (cs > start) blocks.push({ start, end: cs });
  if (end > ce) blocks.push({ start: ce, end });
  return blocks;
}

/** Soma das horas dentro da faixa noturna configurada (atravessa a meia-noite). */
export function nightHours(intervals: Interval[], settings: AppSettings): number {
  const startMin = timeToMinutes(settings.noturno_inicio);
  const endMin = timeToMinutes(settings.noturno_fim);
  const durationMin = endMin > startMin ? endMin - startMin : 24 * 60 - startMin + endMin;
  if (durationMin <= 0) return 0;

  let total = 0;
  for (const block of intervals) {
    const first = new Date(block.start);
    first.setHours(0, 0, 0, 0);
    for (let day = -1; day <= 2; day++) {
      const windowStart = new Date(first);
      windowStart.setDate(windowStart.getDate() + day);
      windowStart.setMinutes(windowStart.getMinutes() + startMin);
      const ws = windowStart.getTime();
      const we = ws + durationMin * 60_000;
      const overlap = Math.min(block.end, we) - Math.max(block.start, ws);
      if (overlap > 0) total += overlap;
    }
  }
  return total / HOUR;
}

export interface ComputedEntry {
  horasTrabalhadas: number;
  horasNoturnas: number;
  horasExtras: number;
  jornadaPrevista: number;
}

/** Cálculo automático a partir das marcações de ponto. */
export function computeEntry(
  entry: TimeEntry,
  employee: Employee,
  settings: AppSettings,
): ComputedEntry {
  const rules = effectiveRules(employee, settings);
  const blocks = workedIntervals(entry, settings.intervalo_descontado);
  const horasTrabalhadas = blocks.reduce((acc, b) => acc + (b.end - b.start), 0) / HOUR;
  const horasNoturnas = nightHours(blocks, settings);
  const horasExtras = Math.max(0, horasTrabalhadas - rules.jornadaDiaria);
  return {
    horasTrabalhadas: round2(horasTrabalhadas),
    horasNoturnas: round2(horasNoturnas),
    horasExtras: round2(horasExtras),
    jornadaPrevista: rules.jornadaDiaria,
  };
}

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export interface EntryTotals {
  diaTrabalhado: boolean;
  horasTrabalhadas: number;
  horasNormais: number;
  horasExtras: number;
  horasNoturnas: number;
  valorDiaria: number;
  valorHorasExtras: number;
  valorHorasNoturnas: number;
  valorVt: number;
  adicionais: number;
  descontos: number;
  outrosCustos: number;
  total: number;
}

/**
 * Converte um registro em valores. Usa os campos já gravados (que podem ter
 * sido corrigidos manualmente pelo administrador).
 */
export function entryTotals(
  entry: TimeEntry,
  employee: Employee,
  settings: AppSettings,
): EntryTotals {
  const rules = effectiveRules(employee, settings);
  const horasTrabalhadas = num(entry.horas_trabalhadas);
  const horasExtras = num(entry.horas_extras);
  const horasNoturnas = num(entry.horas_noturnas);
  const diaTrabalhado = horasTrabalhadas > 0;

  const valorDiaria = diaTrabalhado ? rules.valorDiaria : 0;
  const valorHorasExtras = horasExtras * rules.valorHoraExtra;
  const valorHorasNoturnas = horasNoturnas * rules.valorHoraNoturna;
  const valorVt = entry.vt_aplicado ? num(entry.vt_valor, rules.valorVt) : 0;
  const adicionais = num(entry.adicionais);
  const descontos = num(entry.descontos);
  const outrosCustos = num(entry.outros_custos);

  return {
    diaTrabalhado,
    horasTrabalhadas: round2(horasTrabalhadas),
    horasNormais: round2(Math.max(0, horasTrabalhadas - horasExtras)),
    horasExtras: round2(horasExtras),
    horasNoturnas: round2(horasNoturnas),
    valorDiaria: round2(valorDiaria),
    valorHorasExtras: round2(valorHorasExtras),
    valorHorasNoturnas: round2(valorHorasNoturnas),
    valorVt: round2(valorVt),
    adicionais: round2(adicionais),
    descontos: round2(descontos),
    outrosCustos: round2(outrosCustos),
    total: round2(
      valorDiaria +
        valorHorasExtras +
        valorHorasNoturnas +
        valorVt +
        adicionais +
        outrosCustos -
        descontos,
    ),
  };
}

export interface EmployeeSummary extends EntryTotals {
  employee: Employee;
  diasTrabalhados: number;
}

export function summarizeEmployee(
  employee: Employee,
  entries: TimeEntry[],
  settings: AppSettings,
): EmployeeSummary {
  const base: EmployeeSummary = {
    employee,
    diasTrabalhados: 0,
    diaTrabalhado: false,
    horasTrabalhadas: 0,
    horasNormais: 0,
    horasExtras: 0,
    horasNoturnas: 0,
    valorDiaria: 0,
    valorHorasExtras: 0,
    valorHorasNoturnas: 0,
    valorVt: 0,
    adicionais: 0,
    descontos: 0,
    outrosCustos: 0,
    total: 0,
  };

  for (const entry of entries) {
    const t = entryTotals(entry, employee, settings);
    if (t.diaTrabalhado) base.diasTrabalhados += 1;
    base.horasTrabalhadas += t.horasTrabalhadas;
    base.horasNormais += t.horasNormais;
    base.horasExtras += t.horasExtras;
    base.horasNoturnas += t.horasNoturnas;
    base.valorDiaria += t.valorDiaria;
    base.valorHorasExtras += t.valorHorasExtras;
    base.valorHorasNoturnas += t.valorHorasNoturnas;
    base.valorVt += t.valorVt;
    base.adicionais += t.adicionais;
    base.descontos += t.descontos;
    base.outrosCustos += t.outrosCustos;
    base.total += t.total;
  }

  (Object.keys(base) as (keyof EmployeeSummary)[]).forEach((k) => {
    const v = base[k];
    if (typeof v === "number") (base[k] as number) = round2(v);
  });
  return base;
}

/** Próxima ação possível na tela de ponto — impede registros impossíveis. */
export type PunchAction = "iniciar" | "intervalo" | "retornar" | "finalizar" | "concluido";

export function nextAction(entry: TimeEntry | null | undefined): PunchAction {
  if (!entry || !entry.entrada) return "iniciar";
  if (entry.saida) return "concluido";
  if (entry.intervalo_inicio && !entry.intervalo_fim) return "retornar";
  if (!entry.intervalo_inicio) return "intervalo";
  return "finalizar";
}

export const ACTION_LABEL: Record<PunchAction, string> = {
  iniciar: "Iniciar expediente",
  intervalo: "Iniciar intervalo",
  retornar: "Retornar do intervalo",
  finalizar: "Finalizar expediente",
  concluido: "Expediente concluído",
};

export const STATUS_LABEL: Record<EntryStatus, string> = {
  em_andamento: "Em andamento",
  finalizado: "Finalizado",
  corrigido: "Corrigido",
  aguardando_conferencia: "Aguardando conferência",
  aprovado: "Aprovado",
};

export const TYPE_LABEL: Record<EmployeeType, string> = {
  diarista: "Diarista",
  freelancer: "Freelancer",
  mensalista: "Mensalista",
  outro: "Outro",
};
