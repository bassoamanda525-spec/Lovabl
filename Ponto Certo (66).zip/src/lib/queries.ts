import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  computeEntry,
  type AppSettings,
  type Employee,
  type TimeEntry,
  type PeriodStatus,
} from "@/lib/payroll";

export interface Period {
  id: string;
  nome: string;
  data_inicio: string;
  data_fim: string;
  status: PeriodStatus;
  fechado_em: string | null;
}

export interface EntryPhoto {
  id: string;
  time_entry_id: string;
  employee_id: string;
  tipo: "inicio" | "fim";
  storage_path: string;
  registrado_em: string;
}

export interface Adjustment {
  id: string;
  time_entry_id: string;
  campo: string;
  valor_anterior: string | null;
  valor_novo: string | null;
  justificativa: string;
  alterado_por: string;
  alterado_em: string;
}

/* ---------------------------------- settings --------------------------------- */

export function useSettings() {
  return useQuery({
    queryKey: ["settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("app_settings").select("*").limit(1).single();
      if (error) throw error;
      return data as unknown as AppSettings;
    },
  });
}

export function useUpdateSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: Partial<AppSettings>) => {
      const { error } = await supabase
        .from("app_settings")
        .update(values as never)
        .eq("id", true);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries(),
  });
}

/* --------------------------------- employees --------------------------------- */

export function useEmployees(onlyActive = false) {
  return useQuery({
    queryKey: ["employees", onlyActive],
    queryFn: async () => {
      let q = supabase.from("employees").select("*").order("nome");
      if (onlyActive) q = q.eq("ativo", true);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as Employee[];
    },
  });
}

export function useSaveEmployee() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: Partial<Employee> & { id?: string }) => {
      if (values.id) {
        const { id, ...rest } = values;
        const { error } = await supabase
          .from("employees")
          .update(rest as never)
          .eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("employees").insert(values as never);
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["employees"] }),
  });
}

/* ---------------------------------- periods ---------------------------------- */

export function usePeriods() {
  return useQuery({
    queryKey: ["periods"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("periods")
        .select("*")
        .order("data_inicio", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Period[];
    },
  });
}

export function useSavePeriod() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: Partial<Period> & { id?: string }) => {
      if (values.id) {
        const { id, ...rest } = values;
        const { error } = await supabase
          .from("periods")
          .update(rest as never)
          .eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("periods").insert(values as never);
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["periods"] }),
  });
}

/* --------------------------------- time entries ------------------------------ */

export interface EntryFilter {
  from?: string | undefined;
  to?: string | undefined;
  employeeId?: string | undefined;
  enabled?: boolean | undefined;
}

export function useEntries({ from, to, employeeId, enabled = true }: EntryFilter) {
  return useQuery({
    queryKey: ["entries", from, to, employeeId],
    enabled,
    queryFn: async () => {
      let q = supabase.from("time_entries").select("*").order("data", { ascending: false });
      if (from) q = q.gte("data", from);
      if (to) q = q.lte("data", to);
      if (employeeId) q = q.eq("employee_id", employeeId);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as TimeEntry[];
    },
  });
}

export function useEntryOfDay(employeeId: string | undefined, data: string) {
  return useQuery({
    queryKey: ["entry-day", employeeId, data],
    enabled: !!employeeId,
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("time_entries")
        .select("*")
        .eq("employee_id", employeeId!)
        .eq("data", data)
        .maybeSingle();
      if (error) throw error;
      return (rows as unknown as TimeEntry | null) ?? null;
    },
  });
}

/** Recalcula os campos derivados respeitando correções manuais. */
export function recalculated(entry: TimeEntry, employee: Employee, settings: AppSettings) {
  const c = computeEntry(entry, employee, settings);
  return {
    horas_trabalhadas: c.horasTrabalhadas,
    jornada_prevista: c.jornadaPrevista,
    horas_extras: entry.horas_extras_manual ? entry.horas_extras : c.horasExtras,
    horas_noturnas: entry.horas_noturnas_manual ? entry.horas_noturnas : c.horasNoturnas,
  };
}

export function useSaveEntry() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, values }: { id: string; values: Partial<TimeEntry> }) => {
      const { error } = await supabase
        .from("time_entries")
        .update(values as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries(),
  });
}

export function useLogAdjustments() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (rows: Omit<Adjustment, "id" | "alterado_em" | "alterado_por">[]) => {
      if (!rows.length) return;
      const { data: userData } = await supabase.auth.getUser();
      const payload = rows.map((r) => ({ ...r, alterado_por: userData.user?.id }));
      const { error } = await supabase.from("time_entry_adjustments").insert(payload as never);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["adjustments"] }),
  });
}

export function useAdjustments(entryId: string | undefined) {
  return useQuery({
    queryKey: ["adjustments", entryId],
    enabled: !!entryId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("time_entry_adjustments")
        .select("*")
        .eq("time_entry_id", entryId!)
        .order("alterado_em", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Adjustment[];
    },
  });
}

/* ----------------------------------- photos ---------------------------------- */

export function usePhotos(filter: {
  from?: string | undefined;
  to?: string | undefined;
  employeeId?: string | undefined;
}) {
  return useQuery({
    queryKey: ["photos", filter.from, filter.to, filter.employeeId],
    queryFn: async () => {
      let q = supabase
        .from("time_entry_photos")
        .select("*")
        .order("registrado_em", { ascending: false });
      if (filter.employeeId) q = q.eq("employee_id", filter.employeeId);
      if (filter.from) q = q.gte("registrado_em", `${filter.from}T00:00:00`);
      if (filter.to) q = q.lte("registrado_em", `${filter.to}T23:59:59`);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as unknown as EntryPhoto[];
    },
  });
}

export function usePhotosOfEntries(entryIds: string[]) {
  const key = entryIds.slice().sort().join(",");
  return useQuery({
    queryKey: ["photos-entries", key],
    enabled: entryIds.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("time_entry_photos")
        .select("*")
        .in("time_entry_id", entryIds);
      if (error) throw error;
      return (data ?? []) as unknown as EntryPhoto[];
    },
  });
}

export async function signedPhotoUrl(path: string) {
  const { data, error } = await supabase.storage.from("comprovacoes").createSignedUrl(path, 3600);
  if (error) throw error;
  return data.signedUrl;
}
