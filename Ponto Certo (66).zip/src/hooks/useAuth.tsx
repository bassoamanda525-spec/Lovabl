import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Employee } from "@/lib/payroll";

interface AuthState {
  session: Session | null;
  user: User | null;
  loadingSession: boolean;
  role: "admin" | "colaborador" | null;
  employee: Employee | null;
  profileName: string;
  loadingProfile: boolean;
  isAdmin: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loadingSession, setLoadingSession] = useState(true);
  const queryClient = useQueryClient();

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event, next) => {
      setSession(next);
      setLoadingSession(false);
      if (event === "SIGNED_IN" || event === "SIGNED_OUT" || event === "USER_UPDATED") {
        if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoadingSession(false);
    });
    return () => sub.subscription.unsubscribe();
  }, [queryClient]);

  const userId = session?.user?.id ?? null;

  const { data, isLoading: loadingProfile } = useQuery({
    queryKey: ["me", userId],
    enabled: !!userId,
    queryFn: async () => {
      const [roleRes, profileRes, employeeRes] = await Promise.all([
        supabase.from("user_roles").select("role").eq("user_id", userId!).limit(1).maybeSingle(),
        supabase.from("profiles").select("nome").eq("id", userId!).maybeSingle(),
        supabase.from("employees").select("*").eq("user_id", userId!).maybeSingle(),
      ]);
      return {
        role: (roleRes.data?.role ?? "colaborador") as "admin" | "colaborador",
        nome: profileRes.data?.nome ?? "",
        employee: (employeeRes.data as Employee | null) ?? null,
      };
    },
  });

  const value: AuthState = {
    session,
    user: session?.user ?? null,
    loadingSession,
    role: data?.role ?? null,
    employee: data?.employee ?? null,
    profileName: data?.nome || (session?.user?.email ?? ""),
    loadingProfile: !!userId && loadingProfile,
    isAdmin: data?.role === "admin",
    signOut: async () => {
      await supabase.auth.signOut();
      queryClient.clear();
    },
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth precisa estar dentro de AuthProvider");
  return ctx;
}
