export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          adicional_padrao: number
          created_at: string
          desconto_padrao: number
          forma_calculo_hora_extra: string
          hora_fim_prevista: string
          hora_inicio_prevista: string
          id: boolean
          intervalo_descontado: boolean
          jornada_diaria_horas: number
          jornada_semanal_horas: number
          noturno_fim: string
          noturno_inicio: string
          outros_custos_padrao: number
          percentual_hora_extra: number
          tolerancia_minutos: number
          updated_at: string
          valor_hora_extra: number
          valor_hora_noturna: number
          valor_vt: number
          vt_padrao_ativo: boolean
        }
        Insert: {
          adicional_padrao?: number
          created_at?: string
          desconto_padrao?: number
          forma_calculo_hora_extra?: string
          hora_fim_prevista?: string
          hora_inicio_prevista?: string
          id?: boolean
          intervalo_descontado?: boolean
          jornada_diaria_horas?: number
          jornada_semanal_horas?: number
          noturno_fim?: string
          noturno_inicio?: string
          outros_custos_padrao?: number
          percentual_hora_extra?: number
          tolerancia_minutos?: number
          updated_at?: string
          valor_hora_extra?: number
          valor_hora_noturna?: number
          valor_vt?: number
          vt_padrao_ativo?: boolean
        }
        Update: {
          adicional_padrao?: number
          created_at?: string
          desconto_padrao?: number
          forma_calculo_hora_extra?: string
          hora_fim_prevista?: string
          hora_inicio_prevista?: string
          id?: boolean
          intervalo_descontado?: boolean
          jornada_diaria_horas?: number
          jornada_semanal_horas?: number
          noturno_fim?: string
          noturno_inicio?: string
          outros_custos_padrao?: number
          percentual_hora_extra?: number
          tolerancia_minutos?: number
          updated_at?: string
          valor_hora_extra?: number
          valor_hora_noturna?: number
          valor_vt?: number
          vt_padrao_ativo?: boolean
        }
        Relationships: []
      }
      employees: {
        Row: {
          ativo: boolean
          created_at: string
          documento: string | null
          id: string
          jornada_diaria_horas: number | null
          nome: string
          observacoes: string | null
          tipo: Database["public"]["Enums"]["employee_type"]
          updated_at: string
          user_id: string | null
          valor_diaria: number | null
          valor_hora_extra: number | null
          valor_hora_noturna: number | null
          valor_vt: number | null
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          documento?: string | null
          id?: string
          jornada_diaria_horas?: number | null
          nome: string
          observacoes?: string | null
          tipo?: Database["public"]["Enums"]["employee_type"]
          updated_at?: string
          user_id?: string | null
          valor_diaria?: number | null
          valor_hora_extra?: number | null
          valor_hora_noturna?: number | null
          valor_vt?: number | null
        }
        Update: {
          ativo?: boolean
          created_at?: string
          documento?: string | null
          id?: string
          jornada_diaria_horas?: number | null
          nome?: string
          observacoes?: string | null
          tipo?: Database["public"]["Enums"]["employee_type"]
          updated_at?: string
          user_id?: string | null
          valor_diaria?: number | null
          valor_hora_extra?: number | null
          valor_hora_noturna?: number | null
          valor_vt?: number | null
        }
        Relationships: []
      }
      periods: {
        Row: {
          created_at: string
          data_fim: string
          data_inicio: string
          fechado_em: string | null
          fechado_por: string | null
          id: string
          nome: string
          status: Database["public"]["Enums"]["period_status"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          data_fim: string
          data_inicio: string
          fechado_em?: string | null
          fechado_por?: string | null
          id?: string
          nome: string
          status?: Database["public"]["Enums"]["period_status"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          data_fim?: string
          data_inicio?: string
          fechado_em?: string | null
          fechado_por?: string | null
          id?: string
          nome?: string
          status?: Database["public"]["Enums"]["period_status"]
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          id: string
          nome: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id: string
          nome?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      time_entries: {
        Row: {
          adicionais: number
          created_at: string
          data: string
          descontos: number
          employee_id: string
          entrada: string | null
          horas_extras: number
          horas_extras_manual: boolean
          horas_noturnas: number
          horas_noturnas_manual: boolean
          horas_trabalhadas: number
          id: string
          intervalo_fim: string | null
          intervalo_inicio: string | null
          jornada_prevista: number
          observacoes: string | null
          outros_custos: number
          saida: string | null
          status: Database["public"]["Enums"]["entry_status"]
          updated_at: string
          vt_aplicado: boolean
          vt_valor: number | null
        }
        Insert: {
          adicionais?: number
          created_at?: string
          data: string
          descontos?: number
          employee_id: string
          entrada?: string | null
          horas_extras?: number
          horas_extras_manual?: boolean
          horas_noturnas?: number
          horas_noturnas_manual?: boolean
          horas_trabalhadas?: number
          id?: string
          intervalo_fim?: string | null
          intervalo_inicio?: string | null
          jornada_prevista?: number
          observacoes?: string | null
          outros_custos?: number
          saida?: string | null
          status?: Database["public"]["Enums"]["entry_status"]
          updated_at?: string
          vt_aplicado?: boolean
          vt_valor?: number | null
        }
        Update: {
          adicionais?: number
          created_at?: string
          data?: string
          descontos?: number
          employee_id?: string
          entrada?: string | null
          horas_extras?: number
          horas_extras_manual?: boolean
          horas_noturnas?: number
          horas_noturnas_manual?: boolean
          horas_trabalhadas?: number
          id?: string
          intervalo_fim?: string | null
          intervalo_inicio?: string | null
          jornada_prevista?: number
          observacoes?: string | null
          outros_custos?: number
          saida?: string | null
          status?: Database["public"]["Enums"]["entry_status"]
          updated_at?: string
          vt_aplicado?: boolean
          vt_valor?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "time_entries_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      time_entry_adjustments: {
        Row: {
          alterado_em: string
          alterado_por: string
          campo: string
          id: string
          justificativa: string
          time_entry_id: string
          valor_anterior: string | null
          valor_novo: string | null
        }
        Insert: {
          alterado_em?: string
          alterado_por?: string
          campo: string
          id?: string
          justificativa: string
          time_entry_id: string
          valor_anterior?: string | null
          valor_novo?: string | null
        }
        Update: {
          alterado_em?: string
          alterado_por?: string
          campo?: string
          id?: string
          justificativa?: string
          time_entry_id?: string
          valor_anterior?: string | null
          valor_novo?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "time_entry_adjustments_time_entry_id_fkey"
            columns: ["time_entry_id"]
            isOneToOne: false
            referencedRelation: "time_entries"
            referencedColumns: ["id"]
          },
        ]
      }
      time_entry_photos: {
        Row: {
          created_at: string
          employee_id: string
          id: string
          latitude: number | null
          longitude: number | null
          registrado_em: string
          storage_path: string
          time_entry_id: string
          tipo: Database["public"]["Enums"]["photo_kind"]
        }
        Insert: {
          created_at?: string
          employee_id: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          registrado_em?: string
          storage_path: string
          time_entry_id: string
          tipo: Database["public"]["Enums"]["photo_kind"]
        }
        Update: {
          created_at?: string
          employee_id?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          registrado_em?: string
          storage_path?: string
          time_entry_id?: string
          tipo?: Database["public"]["Enums"]["photo_kind"]
        }
        Relationships: [
          {
            foreignKeyName: "time_entry_photos_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "time_entry_photos_time_entry_id_fkey"
            columns: ["time_entry_id"]
            isOneToOne: false
            referencedRelation: "time_entries"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      current_employee_id: { Args: never; Returns: string }
      date_is_locked: { Args: { _data: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "colaborador"
      employee_type: "diarista" | "freelancer" | "mensalista" | "outro"
      entry_status:
        | "em_andamento"
        | "finalizado"
        | "corrigido"
        | "aguardando_conferencia"
        | "aprovado"
      period_status: "aberto" | "fechado"
      photo_kind: "inicio" | "fim"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "colaborador"],
      employee_type: ["diarista", "freelancer", "mensalista", "outro"],
      entry_status: [
        "em_andamento",
        "finalizado",
        "corrigido",
        "aguardando_conferencia",
        "aprovado",
      ],
      period_status: ["aberto", "fechado"],
      photo_kind: ["inicio", "fim"],
    },
  },
} as const
