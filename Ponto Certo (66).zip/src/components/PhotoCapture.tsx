import { useRef, useState } from "react";
import { Camera, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

interface Props {
  employeeId: string;
  entryId: string;
  tipo: "inicio" | "fim";
  label?: string;
  onSaved?: () => void;
}

/**
 * Captura a foto de comprovação pela câmera do celular e vincula ao registro.
 * A tabela já possui colunas de latitude/longitude reservadas para o futuro,
 * mas nenhuma coleta de GPS é feita nesta versão.
 */
export function PhotoCapture({ employeeId, entryId, tipo, label, onSaved }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  async function handleFile(file: File) {
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${employeeId}/${entryId}/${tipo}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("comprovacoes").upload(path, file, {
        contentType: file.type || "image/jpeg",
      });
      if (upErr) throw upErr;
      const { error } = await supabase.from("time_entry_photos").insert({
        time_entry_id: entryId,
        employee_id: employeeId,
        tipo,
        storage_path: path,
      } as never);
      if (error) throw error;
      toast.success("Comprovação registrada.");
      onSaved?.();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao enviar a foto.");
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void handleFile(file);
        }}
      />
      <Button
        type="button"
        variant="outline"
        className="w-full"
        disabled={uploading}
        onClick={() => inputRef.current?.click()}
      >
        {uploading ? (
          <Loader2 className="mr-2 size-4 animate-spin" />
        ) : (
          <Camera className="mr-2 size-4" />
        )}
        {label ?? (tipo === "inicio" ? "Foto de início" : "Foto de encerramento")}
      </Button>
    </>
  );
}
