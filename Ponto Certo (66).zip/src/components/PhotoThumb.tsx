import { useEffect, useState } from "react";
import { ImageOff } from "lucide-react";
import { signedPhotoUrl, type EntryPhoto } from "@/lib/queries";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { fmtDate, fmtTime } from "@/lib/format";

export function PhotoThumb({ photo, caption }: { photo: EntryPhoto; caption?: string }) {
  const [url, setUrl] = useState<string | null>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    signedPhotoUrl(photo.storage_path)
      .then((u) => alive && setUrl(u))
      .catch(() => alive && setUrl(null));
    return () => {
      alive = false;
    };
  }, [photo.storage_path]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="group relative block size-16 overflow-hidden rounded-md border border-border bg-muted"
        title={`${photo.tipo === "inicio" ? "Início" : "Encerramento"} · ${fmtTime(photo.registrado_em)}`}
      >
        {url ? (
          <img
            src={url}
            alt={`Comprovação de ${photo.tipo === "inicio" ? "início" : "encerramento"} em ${fmtDate(photo.registrado_em)}`}
            className="size-full object-cover transition-transform group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <span className="flex size-full items-center justify-center text-muted-foreground">
            <ImageOff className="size-5" />
          </span>
        )}
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              Comprovação de {photo.tipo === "inicio" ? "início" : "encerramento"} —{" "}
              {fmtDate(photo.registrado_em)} às {fmtTime(photo.registrado_em)}
            </DialogTitle>
          </DialogHeader>
          {url ? (
            <img
              src={url}
              alt={caption ?? "Foto de comprovação do ponto"}
              className="max-h-[70vh] w-full rounded-md object-contain"
            />
          ) : (
            <p className="text-sm text-muted-foreground">Não foi possível carregar a imagem.</p>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
