import { useMemo, useState } from "react";
import { usePeriods, type Period } from "@/lib/queries";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { fmtDate, todayISO } from "@/lib/format";

export interface Range {
  from: string;
  to: string;
  period: Period | null;
}

const CUSTOM = "personalizado";

/**
 * Seleção de intervalo de apuração. Qualquer período cadastrado pode ser
 * escolhido — ou datas livres. Nada é limitado a mês ou quinzena.
 */
export function useRange() {
  const { data: periods = [] } = usePeriods();
  const [periodId, setPeriodId] = useState<string>(CUSTOM);
  const [from, setFrom] = useState(todayISO());
  const [to, setTo] = useState(todayISO());

  const period = useMemo(
    () => periods.find((p) => p.id === periodId) ?? null,
    [periods, periodId],
  );

  const range: Range = period
    ? { from: period.data_inicio, to: period.data_fim, period }
    : { from, to, period: null };

  return { periods, periodId, setPeriodId, from, setFrom, to, setTo, range };
}

export function RangePicker(props: ReturnType<typeof useRange>) {
  const { periods, periodId, setPeriodId, from, setFrom, to, setTo, range } = props;

  return (
    <div className="flex flex-wrap items-end gap-3">
      <div className="min-w-52 space-y-1">
        <Label className="label-caps">Período</Label>
        <Select value={periodId} onValueChange={setPeriodId}>
          <SelectTrigger>
            <SelectValue placeholder="Selecionar" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={CUSTOM}>Datas livres</SelectItem>
            {periods.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {range.period ? (
        <div className="space-y-1">
          <Label className="label-caps">Intervalo</Label>
          <div className="flex h-9 items-center gap-2 text-sm numeric">
            {fmtDate(range.from)} — {fmtDate(range.to)}
            <Badge variant={range.period.status === "aberto" ? "secondary" : "outline"}>
              {range.period.status === "aberto" ? "Aberto" : "Fechado"}
            </Badge>
          </div>
        </div>
      ) : (
        <>
          <div className="space-y-1">
            <Label className="label-caps">De</Label>
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label className="label-caps">Até</Label>
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
        </>
      )}
    </div>
  );
}
