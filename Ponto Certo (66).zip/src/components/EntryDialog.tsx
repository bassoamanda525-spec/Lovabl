import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Lock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAdjustments, recalculated } from "@/lib/queries";
import {
  computeEntry,
  STATUS_LABEL,
  type AppSettings,
  type Employee,
  type EntryStatus,
  type TimeEntry,
} from "@/lib/payroll";
import { fmtDate, fmtHours, fromLocalInput, toLocalInput } from "@/lib/format";
import { useQueryClient } from "@tanstack/react-query";

interface Props {
  entry: TimeEntry | null;
  employee: Employee | undefined;
  settings: AppSettings | undefined;
  locked: boolean;
  onOpenChange: (open: boolean) => void;
}

const FIELD_LABEL: Record<string, string> = {
  entrada: "Entrada",
  intervalo_inicio: "Saída para intervalo",
  intervalo_fim: "Retorno do intervalo",
  saida: "Saída",
  horas_extras: "Horas extras",
  horas_noturnas: "Horas noturnas",
  vt_aplicado: "Vale-transporte",
  vt_valor: "Valor do VT",
  adicionais: "Adicionais",
  descontos: "Descontos",
  outros_custos: "Outros custos",
  observacoes: "Observações",
  status: "Situação",
};

export function EntryDialog({ entry, employee, settings, locked, onOpenChange }: Props) {
  const qc = useQueryClient();
  const [form, setForm] = useState<TimeEntry | null>(entry);
  const [justificativa, setJustificativa] = useState("");
  const [saving, setSaving] = useState(false);
  const { data: adjustments = [] } = useAdjustments(entry?.id);

  useEffect(() => {
    setForm(entry);
    setJustificativa("");
  }, [entry]);

  if (!entry || !form) return null;

  const auto = employee && settings ? computeEntry(form, employee, settings) : null;
  const set = <K extends keyof TimeEntry>(k: K, v: TimeEntry[K]) =>
    setForm((f) => (f ? { ...f, [k]: v } : f));

  async function save() {
    if (!form || !entry || !employee || !settings) return;
    const changed = Object.keys(FIELD_LABEL).filter(
      (k) => String(form[k as keyof TimeEntry] ?? "") !== String(entry[k as keyof TimeEntry] ?? ""),
    );
    if (!changed.length) {
      onOpenChange(false);
      return;
    }
    if (!justificativa.trim()) {
      toast.error("Informe a justificativa da correção.");
      return;
    }
    setSaving(true);
    try {
      const recalc = recalculated(form, employee, settings);
      const values = {
        entrada: form.entrada,
        intervalo_inicio: form.intervalo_inicio,
        intervalo_fim: form.intervalo_fim,
        saida: form.saida,
        horas_extras_manual: form.horas_extras_manual,
        horas_noturnas_manual: form.horas_noturnas_manual,
        vt_aplicado: form.vt_aplicado,
        vt_valor: form.vt_valor,
        adicionais: form.adicionais,
        descontos: form.descontos,
        outros_custos: form.outros_custos,
        observacoes: form.observacoes,
        status: form.status === entry.status ? ("corrigido" as EntryStatus) : form.status,
        ...recalc,
        horas_extras: form.horas_extras_manual ? form.horas_extras : recalc.horas_extras,
        horas_noturnas: form.horas_noturnas_manual ? form.horas_noturnas : recalc.horas_noturnas,
      };
      const { error } = await supabase
        .from("time_entries")
        .update(values as never)
        .eq("id", entry.id);
      if (error) throw error;

      const { data: userData } = await supabase.auth.getUser();
      const rows = changed.map((campo) => ({
        time_entry_id: entry.id,
        campo: FIELD_LABEL[campo] ?? campo,
        valor_anterior: String(entry[campo as keyof TimeEntry] ?? ""),
        valor_novo: String(form[campo as keyof TimeEntry] ?? ""),
        justificativa,
        alterado_por: userData.user?.id,
      }));
      const { error: adjErr } = await supabase
        .from("time_entry_adjustments")
        .insert(rows as never);
      if (adjErr) throw adjErr;

      toast.success("Registro corrigido.");
      qc.invalidateQueries();
      onOpenChange(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao salvar.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!entry} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Correção de ponto — {employee?.nome} · {fmtDate(entry.data)}
          </DialogTitle>
          <DialogDescription>
            Toda alteração é registrada com autor, valores anterior e novo e justificativa.
          </DialogDescription>
        </DialogHeader>

        {locked && (
          <div className="flex items-center gap-2 rounded-md border border-border bg-muted p-3 text-sm">
            <Lock className="size-4" /> Período fechado: alterações bloqueadas. Reabra o período
            para editar.
          </div>
        )}

        <fieldset disabled={locked || saving} className="space-y-5">
          <div className="grid gap-4 sm:grid-cols-2">
            {(["entrada", "intervalo_inicio", "intervalo_fim", "saida"] as const).map((f) => (
              <div key={f} className="space-y-1">
                <Label className="label-caps">{FIELD_LABEL[f]}</Label>
                <Input
                  type="datetime-local"
                  value={toLocalInput(form[f])}
                  onChange={(e) => set(f, fromLocalInput(e.target.value))}
                />
              </div>
            ))}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <ManualHours
              label="Horas extras"
              value={form.horas_extras}
              manual={form.horas_extras_manual}
              autoValue={auto?.horasExtras ?? 0}
              onManual={(v) => set("horas_extras_manual", v)}
              onValue={(v) => set("horas_extras", v)}
            />
            <ManualHours
              label="Horas noturnas"
              value={form.horas_noturnas}
              manual={form.horas_noturnas_manual}
              autoValue={auto?.horasNoturnas ?? 0}
              onManual={(v) => set("horas_noturnas_manual", v)}
              onValue={(v) => set("horas_noturnas", v)}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-4">
            <div className="space-y-1">
              <Label className="label-caps">Vale-transporte</Label>
              <div className="flex h-9 items-center gap-2">
                <Switch
                  checked={form.vt_aplicado}
                  onCheckedChange={(v) => set("vt_aplicado", v)}
                />
                <span className="text-sm">{form.vt_aplicado ? "Recebeu" : "Não recebeu"}</span>
              </div>
            </div>
            <NumField
              label="Valor do VT"
              value={form.vt_valor}
              onChange={(v) => set("vt_valor", v)}
              placeholder="padrão"
            />
            <NumField
              label="Adicionais"
              value={form.adicionais}
              onChange={(v) => set("adicionais", v ?? 0)}
            />
            <NumField
              label="Descontos"
              value={form.descontos}
              onChange={(v) => set("descontos", v ?? 0)}
            />
            <NumField
              label="Outros custos"
              value={form.outros_custos}
              onChange={(v) => set("outros_custos", v ?? 0)}
            />
            <div className="space-y-1 sm:col-span-2">
              <Label className="label-caps">Situação</Label>
              <Select
                value={form.status}
                onValueChange={(v) => set("status", v as EntryStatus)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(STATUS_LABEL).map(([k, v]) => (
                    <SelectItem key={k} value={k}>
                      {v}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1">
            <Label className="label-caps">Observações</Label>
            <Textarea
              value={form.observacoes ?? ""}
              onChange={(e) => set("observacoes", e.target.value)}
            />
          </div>

          <div className="space-y-1">
            <Label className="label-caps">Justificativa da correção</Label>
            <Textarea
              value={justificativa}
              onChange={(e) => setJustificativa(e.target.value)}
              placeholder="Obrigatório ao alterar qualquer campo"
            />
          </div>
        </fieldset>

        {adjustments.length > 0 && (
          <div className="rounded-md border border-border">
            <p className="border-b border-border px-3 py-2 label-caps">Histórico de alterações</p>
            <ul className="max-h-48 divide-y divide-border overflow-y-auto text-sm">
              {adjustments.map((a) => (
                <li key={a.id} className="px-3 py-2">
                  <span className="font-medium">{a.campo}</span>: {a.valor_anterior || "—"} →{" "}
                  {a.valor_novo || "—"}
                  <span className="block text-xs text-muted-foreground">
                    {new Date(a.alterado_em).toLocaleString("pt-BR")} · {a.justificativa}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
          <Button onClick={save} disabled={locked || saving}>
            Salvar correção
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ManualHours({
  label,
  value,
  manual,
  autoValue,
  onManual,
  onValue,
}: {
  label: string;
  value: number;
  manual: boolean;
  autoValue: number;
  onManual: (v: boolean) => void;
  onValue: (v: number) => void;
}) {
  return (
    <div className="space-y-2 rounded-md border border-border p-3">
      <div className="flex items-center justify-between">
        <Label className="label-caps">{label}</Label>
        <Badge variant={manual ? "default" : "secondary"}>
          {manual ? "Manual" : "Automático"}
        </Badge>
      </div>
      <Input
        type="number"
        step="0.01"
        min="0"
        value={manual ? value : autoValue}
        disabled={!manual}
        onChange={(e) => onValue(Number(e.target.value))}
      />
      <div className="flex items-center gap-2">
        <Switch checked={manual} onCheckedChange={onManual} />
        <span className="text-xs text-muted-foreground">
          Ajustar manualmente (cálculo automático: {fmtHours(autoValue)})
        </span>
      </div>
    </div>
  );
}

function NumField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder?: string;
}) {
  return (
    <div className="space-y-1">
      <Label className="label-caps">{label}</Label>
      <Input
        type="number"
        step="0.01"
        value={value ?? ""}
        placeholder={placeholder ?? "0,00"}
        onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
      />
    </div>
  );
}
