import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Clock } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Controle Operacional — Ponto digital de equipes" },
      {
        name: "description",
        content:
          "Registre jornada, intervalos, horas extras e noturnas e apure diárias, vale-transporte e custos em qualquer período.",
      },
      { property: "og:title", content: "Controle Operacional — Ponto digital de equipes" },
      {
        property: "og:description",
        content:
          "Ponto digital operacional com apuração de horas extras, horas noturnas, diárias e custos.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { loadingSession, loadingProfile, session, isAdmin, role } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (loadingSession) return;
    if (!session) {
      navigate({ to: "/auth", replace: true });
      return;
    }
    if (loadingProfile || !role) return;
    navigate({ to: isAdmin ? "/admin" : "/ponto", replace: true });
  }, [loadingSession, loadingProfile, session, role, isAdmin, navigate]);

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-6 text-center">
      <div className="flex size-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
        <Clock className="size-7" />
      </div>
      <h1 className="font-display text-3xl font-bold uppercase tracking-wide">
        Controle Operacional
      </h1>
      <p className="text-sm text-muted-foreground">Carregando seu painel…</p>
    </main>
  );
}
