import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useEmployees, usePhotos } from "@/lib/queries";
import { RangePicker, useRange } from "@/components/RangePicker";
import { PhotoThumb } from "@/components/PhotoThumb";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/admin/comprovacoes")({
  head: () => ({
    meta: [
      { title: "Comprovações — Controle Operacional" },
      { name: "description", content: "Fotos de comprovação de início e fim de jornada." },
      { property: "og:title", content: "Comprovações — Controle Operacional" },
      { property: "og:description", content: "Galeria de comprovação de presença em campo." },
    ],
  }),
  component: Comprovacoes,
});

const ALL = "todos";

function Comprovacoes() {
  const rangeState = useRange();
  const { from, to } = rangeState.range;
  const [employeeId, setEmployeeId] = useState(ALL);
  const { data: employees = [] } = useEmployees();
  const { data: photos = [] } = usePhotos({
    from,
    to,
    employeeId: employeeId === ALL ? undefined : employeeId,
  });
  const byId = useMemo(() => new Map(employees.map((e) => [e.id, e])), [employees]);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Comprovações</h1>
        <p className="text-sm text-muted-foreground">
          Fotos enviadas pelos colaboradores no início e no fim da jornada.
        </p>
      </header>

      <div className="panel flex flex-wrap items-end gap-3 p-4">
        <RangePicker {...rangeState} />
        <div className="min-w-52 space-y-1">
          <Label className="label-caps">Colaborador</Label>
          <Select value={employeeId} onValueChange={setEmployeeId}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todos</SelectItem>
              {employees.map((e) => (
                <SelectItem key={e.id} value={e.id}>
                  {e.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {photos.length === 0 ? (
        <p className="panel p-8 text-center text-muted-foreground">
          Nenhuma comprovação no filtro selecionado.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {photos.map((p) => (
            <PhotoThumb
              key={p.id}
              photo={p}
              caption={`${byId.get(p.employee_id)?.nome ?? "—"} · ${
                p.tipo === "inicio" ? "Início" : "Fim"
              } · ${new Date(p.registrado_em).toLocaleString("pt-BR")}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
