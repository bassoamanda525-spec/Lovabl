import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { CalendarDays, Clock, Moon, Receipt, TrendingUp, Users, Wallet } from "lucide-react";
import { useEmployees, useEntries, useSettings } from "@/lib/queries";
import { RangePicker, useRange } from "@/components/RangePicker";
import { summarizeEmployee, type EmployeeSummary } from "@/lib/payroll";
import { fmtHours, fmtMoney } from "@/lib/format";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Controle Operacional" },
      { name: "description", content: "Visão consolidada de jornada, horas e custos do período." },
      { property: "og:title", content: "Dashboard — Controle Operacional" },
      { property: "og:description", content: "Indicadores operacionais por período." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const range = useRange();
  const { from, to } = range.range;
  const { data: settings } = useSettings();
  const { data: employees = [] } = useEmployees();
  const { data: entries = [] } = useEntries({ from, to });

  const summaries = useMemo<EmployeeSummary[]>(() => {
    if (!settings) return [];
    return employees
      .map((e) =>
        summarizeEmployee(
          e,
          entries.filter((x) => x.employee_id === e.id),
          settings,
        ),
      )
      .filter((s) => s.diasTrabalhados > 0 || s.total !== 0);
  }, [employees, entries, settings]);

  const t = summaries.reduce(
    (acc, s) => ({
      dias: acc.dias + s.diasTrabalhados,
      horas: acc.horas + s.horasTrabalhadas,
      extras: acc.extras + s.horasExtras,
      noturnas: acc.noturnas + s.horasNoturnas,
      diarias: acc.diarias + s.valorDiaria,
      vExtras: acc.vExtras + s.valorHorasExtras,
      vNoturnas: acc.vNoturnas + s.valorHorasNoturnas,
      vt: acc.vt + s.valorVt,
      outros: acc.outros + s.outrosCustos + s.adicionais - s.descontos,
      total: acc.total + s.total,
    }),
    {
      dias: 0,
      horas: 0,
      extras: 0,
      noturnas: 0,
      diarias: 0,
      vExtras: 0,
      vNoturnas: 0,
      vt: 0,
      outros: 0,
      total: 0,
    },
  );

  const ativos = employees.filter((e) => e.ativo).length;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Selecione um período de apuração ou datas livres.
        </p>
      </header>

      <div className="panel p-4">
        <RangePicker {...range} />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat icon={Users} label="Colaboradores ativos" value={String(ativos)} />
        <Stat icon={CalendarDays} label="Dias trabalhados" value={String(t.dias)} />
        <Stat icon={Clock} label="Horas trabalhadas" value={fmtHours(t.horas)} />
        <Stat icon={TrendingUp} label="Horas extras" value={fmtHours(t.extras)} />
        <Stat icon={Moon} label="Horas noturnas" value={fmtHours(t.noturnas)} />
        <Stat icon={Wallet} label="Total de diárias" value={fmtMoney(t.diarias)} />
        <Stat icon={TrendingUp} label="Total horas extras" value={fmtMoney(t.vExtras)} />
        <Stat icon={Moon} label="Total horas noturnas" value={fmtMoney(t.vNoturnas)} />
        <Stat icon={Receipt} label="Total de VT" value={fmtMoney(t.vt)} />
        <Stat icon={Receipt} label="Outros custos" value={fmtMoney(t.outros)} />
        <Stat icon={Wallet} label="Custo total" value={fmtMoney(t.total)} highlight />
      </div>

      <div className="panel overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Colaborador</TableHead>
              <TableHead className="text-right">Dias</TableHead>
              <TableHead className="text-right">Horas</TableHead>
              <TableHead className="text-right">Extras</TableHead>
              <TableHead className="text-right">Noturnas</TableHead>
              <TableHead className="text-right">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {summaries.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-muted-foreground">
                  Nenhum registro no período selecionado.
                </TableCell>
              </TableRow>
            )}
            {summaries.map((s) => (
              <TableRow key={s.employee.id}>
                <TableCell className="font-medium">{s.employee.nome}</TableCell>
                <TableCell className="numeric text-right">{s.diasTrabalhados}</TableCell>
                <TableCell className="numeric text-right">{fmtHours(s.horasTrabalhadas)}</TableCell>
                <TableCell className="numeric text-right">{fmtHours(s.horasExtras)}</TableCell>
                <TableCell className="numeric text-right">{fmtHours(s.horasNoturnas)}</TableCell>
                <TableCell className="numeric text-right font-semibold">
                  {fmtMoney(s.total)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
  highlight,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className={`panel p-4 ${highlight ? "border-accent" : ""}`}>
      <div className="flex items-center gap-2">
        <Icon className="size-4 text-muted-foreground" />
        <span className="label-caps">{label}</span>
      </div>
      <p className="numeric mt-2 font-display text-2xl font-bold">{value}</p>
    </div>
  );
}
