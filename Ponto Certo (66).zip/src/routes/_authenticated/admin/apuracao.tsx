import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useEmployees, useEntries, useSettings } from "@/lib/queries";
import { RangePicker, useRange } from "@/components/RangePicker";
import { entryTotals, summarizeEmployee } from "@/lib/payroll";
import { fmtDate, fmtHours, fmtMoney } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin/apuracao")({
  head: () => ({
    meta: [
      { title: "Apuração — Controle Operacional" },
      { name: "description", content: "Apuração de pagamento por colaborador em qualquer período." },
      { property: "og:title", content: "Apuração — Controle Operacional" },
      { property: "og:description", content: "Diárias, horas extras, noturnas, VT e custos." },
    ],
  }),
  component: Apuracao,
});

function Apuracao() {
  const rangeState = useRange();
  const { from, to, period } = rangeState.range;
  const { data: settings } = useSettings();
  const { data: employees = [] } = useEmployees();
  const { data: entries = [] } = useEntries({ from, to });
  const [openId, setOpenId] = useState<string | null>(null);

  const summaries = useMemo(() => {
    if (!settings) return [];
    return employees
      .map((e) => ({
        summary: summarizeEmployee(
          e,
          entries.filter((x) => x.employee_id === e.id),
          settings,
        ),
        entries: entries.filter((x) => x.employee_id === e.id),
      }))
      .filter((s) => s.entries.length > 0);
  }, [employees, entries, settings]);

  const total = summaries.reduce((a, s) => a + s.summary.total, 0);

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Apuração</h1>
          <p className="text-sm text-muted-foreground">
            {fmtDate(from)} a {fmtDate(to)}
            {period ? ` · ${period.nome}` : ""}
          </p>
        </div>
        {period && (
          <Badge variant={period.status === "aberto" ? "default" : "outline"}>
            {period.status === "aberto" ? "Período aberto" : "Período fechado"}
          </Badge>
        )}
      </header>

      <div className="panel p-4">
        <RangePicker {...rangeState} />
      </div>

      <div className="panel overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Colaborador</TableHead>
              <TableHead className="text-right">Dias</TableHead>
              <TableHead className="text-right">Horas</TableHead>
              <TableHead className="text-right">Extras</TableHead>
              <TableHead className="text-right">Noturnas</TableHead>
              <TableHead className="text-right">Diárias</TableHead>
              <TableHead className="text-right">V. extras</TableHead>
              <TableHead className="text-right">V. noturnas</TableHead>
              <TableHead className="text-right">VT</TableHead>
              <TableHead className="text-right">Adic.</TableHead>
              <TableHead className="text-right">Desc.</TableHead>
              <TableHead className="text-right">Outros</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {summaries.map(({ summary: s, entries: rows }) => (
              <>
                <TableRow key={s.employee.id}>
                  <TableCell className="font-medium">{s.employee.nome}</TableCell>
                  <TableCell className="numeric text-right">{s.diasTrabalhados}</TableCell>
                  <TableCell className="numeric text-right">
                    {fmtHours(s.horasTrabalhadas)}
                  </TableCell>
                  <TableCell className="numeric text-right">{fmtHours(s.horasExtras)}</TableCell>
                  <TableCell className="numeric text-right">{fmtHours(s.horasNoturnas)}</TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(s.valorDiaria)}</TableCell>
                  <TableCell className="numeric text-right">
                    {fmtMoney(s.valorHorasExtras)}
                  </TableCell>
                  <TableCell className="numeric text-right">
                    {fmtMoney(s.valorHorasNoturnas)}
                  </TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(s.valorVt)}</TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(s.adicionais)}</TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(s.descontos)}</TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(s.outrosCustos)}</TableCell>
                  <TableCell className="numeric text-right font-semibold">
                    {fmtMoney(s.total)}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setOpenId(openId === s.employee.id ? null : s.employee.id)}
                    >
                      {openId === s.employee.id ? "Ocultar" : "Detalhar"}
                    </Button>
                  </TableCell>
                </TableRow>
                {openId === s.employee.id &&
                  rows.map((entry) => {
                    const t = settings ? entryTotals(entry, s.employee, settings) : null;
                    return (
                      <TableRow key={entry.id} className="bg-muted/40 text-xs">
                        <TableCell className="pl-8">{fmtDate(entry.data)}</TableCell>
                        <TableCell className="numeric text-right">
                          {t?.diaTrabalhado ? 1 : 0}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtHours(entry.horas_trabalhadas)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtHours(entry.horas_extras)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtHours(entry.horas_noturnas)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtMoney(t?.valorDiaria)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtMoney(t?.valorHorasExtras)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtMoney(t?.valorHorasNoturnas)}
                        </TableCell>
                        <TableCell className="numeric text-right">{fmtMoney(t?.valorVt)}</TableCell>
                        <TableCell className="numeric text-right">
                          {fmtMoney(t?.adicionais)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtMoney(t?.descontos)}
                        </TableCell>
                        <TableCell className="numeric text-right">
                          {fmtMoney(t?.outrosCustos)}
                        </TableCell>
                        <TableCell className="numeric text-right">{fmtMoney(t?.total)}</TableCell>
                        <TableCell />
                      </TableRow>
                    );
                  })}
              </>
            ))}
            {summaries.length === 0 && (
              <TableRow>
                <TableCell colSpan={14} className="text-center text-muted-foreground">
                  Nenhum registro no período.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TableCell colSpan={12} className="font-display uppercase">
                Total do período
              </TableCell>
              <TableCell className="numeric text-right font-bold">{fmtMoney(total)}</TableCell>
              <TableCell />
            </TableRow>
          </TableFooter>
        </Table>
      </div>
    </div>
  );
}
