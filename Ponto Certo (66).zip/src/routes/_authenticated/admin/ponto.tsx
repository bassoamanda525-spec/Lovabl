import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Pencil } from "lucide-react";
import { useEmployees, useEntries, usePeriods, useSettings } from "@/lib/queries";
import { RangePicker, useRange } from "@/components/RangePicker";
import { EntryDialog } from "@/components/EntryDialog";
import { STATUS_LABEL, entryTotals, type TimeEntry } from "@/lib/payroll";
import { fmtDate, fmtHours, fmtMoney, fmtTime } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin/ponto")({
  head: () => ({
    meta: [
      { title: "Ponto — Controle Operacional" },
      { name: "description", content: "Registros de ponto da equipe com correção auditada." },
      { property: "og:title", content: "Ponto — Controle Operacional" },
      { property: "og:description", content: "Conferência e correção dos registros de jornada." },
    ],
  }),
  component: PontoAdmin,
});

const ALL = "todos";

function PontoAdmin() {
  const rangeState = useRange();
  const { from, to } = rangeState.range;
  const [employeeId, setEmployeeId] = useState(ALL);
  const [editing, setEditing] = useState<TimeEntry | null>(null);

  const { data: settings } = useSettings();
  const { data: employees = [] } = useEmployees();
  const { data: periods = [] } = usePeriods();
  const { data: entries = [] } = useEntries({
    from,
    to,
    employeeId: employeeId === ALL ? undefined : employeeId,
  });

  const byId = useMemo(() => new Map(employees.map((e) => [e.id, e])), [employees]);
  const isLocked = (data: string) =>
    periods.some((p) => p.status === "fechado" && data >= p.data_inicio && data <= p.data_fim);

  return (
    <div className="space-y-6">
      <header>
        <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Ponto</h1>
        <p className="text-sm text-muted-foreground">
          Toda correção exige justificativa e fica registrada no histórico.
        </p>
      </header>

      <div className="panel flex flex-wrap items-end gap-3 p-4">
        <RangePicker {...rangeState} />
        <div className="min-w-52 space-y-1">
          <Label className="label-caps">Colaborador</Label>
          <Select value={employeeId} onValueChange={setEmployeeId}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>Todos</SelectItem>
              {employees.map((e) => (
                <SelectItem key={e.id} value={e.id}>
                  {e.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="panel overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Colaborador</TableHead>
              <TableHead>Entrada</TableHead>
              <TableHead>Intervalo</TableHead>
              <TableHead>Saída</TableHead>
              <TableHead className="text-right">Horas</TableHead>
              <TableHead className="text-right">Extras</TableHead>
              <TableHead className="text-right">Noturnas</TableHead>
              <TableHead className="text-right">Valor</TableHead>
              <TableHead>Situação</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {entries.map((entry) => {
              const emp = byId.get(entry.employee_id);
              const totals = emp && settings ? entryTotals(entry, emp, settings) : null;
              const locked = isLocked(entry.data);
              return (
                <TableRow key={entry.id}>
                  <TableCell className="numeric">{fmtDate(entry.data)}</TableCell>
                  <TableCell className="font-medium">{emp?.nome ?? "—"}</TableCell>
                  <TableCell className="numeric">{fmtTime(entry.entrada)}</TableCell>
                  <TableCell className="numeric">
                    {fmtTime(entry.intervalo_inicio)} – {fmtTime(entry.intervalo_fim)}
                  </TableCell>
                  <TableCell className="numeric">{fmtTime(entry.saida)}</TableCell>
                  <TableCell className="numeric text-right">
                    {fmtHours(entry.horas_trabalhadas)}
                  </TableCell>
                  <TableCell className="numeric text-right">
                    {fmtHours(entry.horas_extras)}
                  </TableCell>
                  <TableCell className="numeric text-right">
                    {fmtHours(entry.horas_noturnas)}
                  </TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(totals?.total)}</TableCell>
                  <TableCell>
                    <Badge variant={entry.status === "aprovado" ? "default" : "secondary"}>
                      {STATUS_LABEL[entry.status]}
                    </Badge>
                    {locked && (
                      <span className="ml-1 text-xs text-muted-foreground">(fechado)</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => setEditing(entry)}>
                      <Pencil className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
            {entries.length === 0 && (
              <TableRow>
                <TableCell colSpan={11} className="text-center text-muted-foreground">
                  Nenhum registro no filtro selecionado.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <EntryDialog
        entry={editing}
        employee={editing ? byId.get(editing.employee_id) : undefined}
        settings={settings}
        locked={editing ? isLocked(editing.data) : false}
        onOpenChange={(o) => !o && setEditing(null)}
      />
    </div>
  );
}
