import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Lock, LockOpen, Plus } from "lucide-react";
import { usePeriods, useSavePeriod, type Period } from "@/lib/queries";
import { fmtDate, todayISO } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin/periodos")({
  head: () => ({
    meta: [
      { title: "Períodos — Controle Operacional" },
      { name: "description", content: "Crie qualquer período de apuração e controle o fechamento." },
      { property: "og:title", content: "Períodos — Controle Operacional" },
      { property: "og:description", content: "Períodos livres de apuração, sem limite de datas." },
    ],
  }),
  component: Periodos,
});

type Draft = Partial<Period> & { id?: string };

function Periodos() {
  const { data: periods = [] } = usePeriods();
  const save = useSavePeriod();
  const [draft, setDraft] = useState<Draft | null>(null);

  async function submit() {
    if (!draft?.nome?.trim() || !draft.data_inicio || !draft.data_fim) {
      toast.error("Informe nome, data inicial e data final.");
      return;
    }
    if (draft.data_fim < draft.data_inicio) {
      toast.error("A data final deve ser posterior à inicial.");
      return;
    }
    try {
      await save.mutateAsync(draft);
      toast.success("Período salvo.");
      setDraft(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao salvar.");
    }
  }

  async function toggle(p: Period) {
    const fechando = p.status === "aberto";
    try {
      await save.mutateAsync({
        id: p.id,
        status: fechando ? "fechado" : "aberto",
        fechado_em: fechando ? new Date().toISOString() : null,
      });
      toast.success(fechando ? "Período fechado." : "Período reaberto.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao alterar o período.");
    }
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Períodos</h1>
          <p className="text-sm text-muted-foreground">
            Qualquer intervalo de datas pode ser usado na apuração.
          </p>
        </div>
        <Button
          onClick={() =>
            setDraft({ nome: "", data_inicio: todayISO(), data_fim: todayISO(), status: "aberto" })
          }
        >
          <Plus className="mr-2 size-4" /> Novo período
        </Button>
      </header>

      <div className="panel overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Início</TableHead>
              <TableHead>Fim</TableHead>
              <TableHead>Situação</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {periods.map((p) => (
              <TableRow key={p.id}>
                <TableCell className="font-medium">{p.nome}</TableCell>
                <TableCell className="numeric">{fmtDate(p.data_inicio)}</TableCell>
                <TableCell className="numeric">{fmtDate(p.data_fim)}</TableCell>
                <TableCell>
                  <Badge variant={p.status === "aberto" ? "default" : "outline"}>
                    {p.status === "aberto" ? "Aberto" : "Fechado"}
                  </Badge>
                </TableCell>
                <TableCell className="space-x-2 text-right">
                  <Button variant="outline" size="sm" onClick={() => setDraft({ ...p })}>
                    Editar
                  </Button>
                  <Button
                    variant={p.status === "aberto" ? "secondary" : "default"}
                    size="sm"
                    onClick={() => toggle(p)}
                  >
                    {p.status === "aberto" ? (
                      <>
                        <Lock className="mr-2 size-4" /> Fechar
                      </>
                    ) : (
                      <>
                        <LockOpen className="mr-2 size-4" /> Reabrir
                      </>
                    )}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {periods.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground">
                  Nenhum período criado.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Editar período" : "Novo período"}</DialogTitle>
            <DialogDescription>
              O período define apenas quais registros entram na apuração.
            </DialogDescription>
          </DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="space-y-1">
                <Label className="label-caps">Nome</Label>
                <Input
                  value={draft.nome ?? ""}
                  placeholder="Ex.: 17/08 a 30/08"
                  onChange={(e) => setDraft({ ...draft, nome: e.target.value })}
                />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1">
                  <Label className="label-caps">Data inicial</Label>
                  <Input
                    type="date"
                    value={draft.data_inicio ?? ""}
                    onChange={(e) => setDraft({ ...draft, data_inicio: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <Label className="label-caps">Data final</Label>
                  <Input
                    type="date"
                    value={draft.data_fim ?? ""}
                    onChange={(e) => setDraft({ ...draft, data_fim: e.target.value })}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDraft(null)}>
              Cancelar
            </Button>
            <Button onClick={submit} disabled={save.isPending}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
