import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Pencil, Plus } from "lucide-react";
import { useEmployees, useSaveEmployee, useSettings } from "@/lib/queries";
import { TYPE_LABEL, effectiveRules, type Employee, type EmployeeType } from "@/lib/payroll";
import { fmtMoney, fmtHours } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin/colaboradores")({
  head: () => ({
    meta: [
      { title: "Colaboradores — Controle Operacional" },
      { name: "description", content: "Cadastro de colaboradores, valores e regras específicas." },
      { property: "og:title", content: "Colaboradores — Controle Operacional" },
      { property: "og:description", content: "Gestão do cadastro da equipe operacional." },
    ],
  }),
  component: Colaboradores,
});

type Draft = Partial<Employee> & { id?: string };

const EMPTY: Draft = { nome: "", tipo: "diarista", ativo: true };

function Colaboradores() {
  const { data: employees = [] } = useEmployees();
  const { data: settings } = useSettings();
  const save = useSaveEmployee();
  const [draft, setDraft] = useState<Draft | null>(null);

  async function submit() {
    if (!draft?.nome?.trim()) {
      toast.error("Informe o nome do colaborador.");
      return;
    }
    try {
      await save.mutateAsync({
        ...draft,
        user_id: draft.user_id?.trim() ? draft.user_id.trim() : null,
      });
      toast.success("Colaborador salvo.");
      setDraft(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao salvar.");
    }
  }

  const setField = <K extends keyof Draft>(k: K, v: Draft[K]) =>
    setDraft((d) => (d ? { ...d, [k]: v } : d));

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold uppercase tracking-wide">Colaboradores</h1>
          <p className="text-sm text-muted-foreground">
            Regras específicas do colaborador prevalecem sobre as configurações padrão.
          </p>
        </div>
        <Button onClick={() => setDraft({ ...EMPTY })}>
          <Plus className="mr-2 size-4" /> Novo colaborador
        </Button>
      </header>

      <div className="panel overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>Documento</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead className="text-right">Diária</TableHead>
              <TableHead className="text-right">Jornada</TableHead>
              <TableHead className="text-right">Hora extra</TableHead>
              <TableHead className="text-right">Hora noturna</TableHead>
              <TableHead className="text-right">VT</TableHead>
              <TableHead>Status</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {employees.map((e) => {
              const r = settings ? effectiveRules(e, settings) : null;
              return (
                <TableRow key={e.id}>
                  <TableCell className="font-medium">{e.nome}</TableCell>
                  <TableCell>{e.documento || "—"}</TableCell>
                  <TableCell>{TYPE_LABEL[e.tipo]}</TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(r?.valorDiaria)}</TableCell>
                  <TableCell className="numeric text-right">{fmtHours(r?.jornadaDiaria)}</TableCell>
                  <TableCell className="numeric text-right">
                    {fmtMoney(r?.valorHoraExtra)}
                  </TableCell>
                  <TableCell className="numeric text-right">
                    {fmtMoney(r?.valorHoraNoturna)}
                  </TableCell>
                  <TableCell className="numeric text-right">{fmtMoney(r?.valorVt)}</TableCell>
                  <TableCell>
                    <Badge variant={e.ativo ? "default" : "outline"}>
                      {e.ativo ? "Ativo" : "Inativo"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => setDraft({ ...e })}>
                      <Pencil className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
            {employees.length === 0 && (
              <TableRow>
                <TableCell colSpan={10} className="text-center text-muted-foreground">
                  Nenhum colaborador cadastrado.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{draft?.id ? "Editar colaborador" : "Novo colaborador"}</DialogTitle>
            <DialogDescription>
              Campos de valores em branco usam a configuração padrão do sistema.
            </DialogDescription>
          </DialogHeader>

          {draft && (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1 sm:col-span-2">
                <Label className="label-caps">Nome completo</Label>
                <Input
                  value={draft.nome ?? ""}
                  onChange={(e) => setField("nome", e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label className="label-caps">CPF ou identificador</Label>
                <Input
                  value={draft.documento ?? ""}
                  onChange={(e) => setField("documento", e.target.value)}
                />
              </div>
              <div className="space-y-1">
                <Label className="label-caps">Tipo</Label>
                <Select
                  value={draft.tipo ?? "diarista"}
                  onValueChange={(v) => setField("tipo", v as EmployeeType)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_LABEL).map(([k, v]) => (
                      <SelectItem key={k} value={k}>
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Num
                label="Valor da diária"
                value={draft.valor_diaria ?? null}
                onChange={(v) => setField("valor_diaria", v)}
              />
              <Num
                label="Jornada diária (horas)"
                value={draft.jornada_diaria_horas ?? null}
                onChange={(v) => setField("jornada_diaria_horas", v)}
                placeholder={String(settings?.jornada_diaria_horas ?? "")}
              />
              <Num
                label="Valor da hora extra"
                value={draft.valor_hora_extra ?? null}
                onChange={(v) => setField("valor_hora_extra", v)}
                placeholder="padrão"
              />
              <Num
                label="Valor da hora noturna"
                value={draft.valor_hora_noturna ?? null}
                onChange={(v) => setField("valor_hora_noturna", v)}
                placeholder="padrão"
              />
              <Num
                label="Valor do vale-transporte"
                value={draft.valor_vt ?? null}
                onChange={(v) => setField("valor_vt", v)}
                placeholder="padrão"
              />

              <div className="space-y-1">
                <Label className="label-caps">Situação</Label>
                <div className="flex h-9 items-center gap-2">
                  <Switch
                    checked={draft.ativo ?? true}
                    onCheckedChange={(v) => setField("ativo", v)}
                  />
                  <span className="text-sm">{draft.ativo ?? true ? "Ativo" : "Inativo"}</span>
                </div>
              </div>

              <div className="space-y-1 sm:col-span-2">
                <Label className="label-caps">ID do usuário de acesso (opcional)</Label>
                <Input
                  value={draft.user_id ?? ""}
                  placeholder="Cole o ID do usuário para vincular o login ao colaborador"
                  onChange={(e) => setField("user_id", e.target.value)}
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <Label className="label-caps">Observações</Label>
                <Textarea
                  value={draft.observacoes ?? ""}
                  onChange={(e) => setField("observacoes", e.target.value)}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setDraft(null)}>
              Cancelar
            </Button>
            <Button onClick={submit} disabled={save.isPending}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Num({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: number | null;
  onChange: (v: number | null) => void;
  placeholder?: string;
}) {
  return (
    <div className="space-y-1">
      <Label className="label-caps">{label}</Label>
      <Input
        type="number"
        step="0.01"
        value={value ?? ""}
        placeholder={placeholder ?? "padrão"}
        onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
      />
    </div>
  );
}
