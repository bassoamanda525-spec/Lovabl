import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  CalendarRange,
  Calculator,
  Camera,
  Clock,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  Users,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminLayout,
});

const NAV = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/colaboradores", label: "Colaboradores", icon: Users, exact: false },
  { to: "/admin/ponto", label: "Ponto", icon: Clock, exact: false },
  { to: "/admin/periodos", label: "Períodos", icon: CalendarRange, exact: false },
  { to: "/admin/apuracao", label: "Apuração", icon: Calculator, exact: false },
  { to: "/admin/comprovacoes", label: "Comprovações", icon: Camera, exact: false },
  { to: "/admin/configuracoes", label: "Configurações", icon: Settings, exact: false },
] as const;

function AdminLayout() {
  const { isAdmin, loadingProfile, role, profileName, signOut } = useAuth();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!loadingProfile && role && !isAdmin) navigate({ to: "/ponto", replace: true });
  }, [isAdmin, role, loadingProfile, navigate]);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <div className="flex min-h-screen bg-background">
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 -translate-x-full flex-col bg-sidebar text-sidebar-foreground transition-transform lg:static lg:translate-x-0 lg:flex",
          open && "translate-x-0",
          "flex",
        )}
      >
        <div className="border-b border-sidebar-border px-5 py-5">
          <p className="font-display text-lg font-bold uppercase tracking-widest text-sidebar-primary">
            Controle
          </p>
          <p className="font-display text-lg font-bold uppercase tracking-widest">Operacional</p>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {NAV.map((item) => {
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <item.icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <p className="px-3 pb-2 text-xs opacity-70">{profileName}</p>
          <Button
            variant="ghost"
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={signOut}
          >
            <LogOut className="mr-2 size-4" /> Sair
          </Button>
        </div>
      </aside>

      {open && (
        <button
          aria-label="Fechar menu"
          className="fixed inset-0 z-30 bg-foreground/40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center gap-3 border-b border-border bg-card px-4 py-3 lg:hidden">
          <Button variant="ghost" size="icon" onClick={() => setOpen(true)} aria-label="Abrir menu">
            <Menu className="size-5" />
          </Button>
          <span className="font-display font-bold uppercase tracking-wide">Controle Operacional</span>
        </header>
        <main className="min-w-0 flex-1 p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
