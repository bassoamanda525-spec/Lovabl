import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { CalendarDays, ClipboardList, Coffee, LogOut, Play, Square, Undo2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useEntryOfDay, usePhotosOfEntries, useSettings, recalculated } from "@/lib/queries";
import { ACTION_LABEL, nextAction, STATUS_LABEL, type TimeEntry } from "@/lib/payroll";
import { fmtDateLong, fmtHours, fmtTime, todayISO } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PhotoCapture } from "@/components/PhotoCapture";
import { PhotoThumb } from "@/components/PhotoThumb";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/_authenticated/ponto")({
  head: () => ({
    meta: [
      { title: "Meu Ponto — Controle Operacional" },
      { name: "description", content: "Registre entrada, intervalo, retorno e saída do dia." },
      { property: "og:title", content: "Meu Ponto — Controle Operacional" },
      { property: "og:description", content: "Registro de jornada pelo celular." },
    ],
  }),
  component: PontoPage,
});

function PontoPage() {
  const { employee, profileName, signOut } = useAuth();
  const hoje = todayISO();
  const { data: settings } = useSettings();
  const { data: entry, refetch } = useEntryOfDay(employee?.id, hoje);
  const { data: photos = [], refetch: refetchPhotos } = usePhotosOfEntries(
    entry ? [entry.id] : [],
  );
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [, tick] = useState(0);

  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 30_000);
    return () => clearInterval(t);
  }, []);

  const action = nextAction(entry);

  async function punch() {
    if (!employee || !settings || busy) return;
    setBusy(true);
    const now = new Date().toISOString();
    try {
      if (action === "iniciar") {
        const { error } = await supabase.from("time_entries").insert({
          employee_id: employee.id,
          data: hoje,
          entrada: now,
          jornada_prevista: employee.jornada_diaria_horas ?? settings.jornada_diaria_horas,
          vt_aplicado: settings.vt_padrao_ativo,
          status: "em_andamento",
        } as never);
        if (error) throw error;
      } else if (entry) {
        const patch: Partial<TimeEntry> = {};
        if (action === "intervalo") patch.intervalo_inicio = now;
        if (action === "retornar") patch.intervalo_fim = now;
        if (action === "finalizar") patch.saida = now;

        const draft = { ...entry, ...patch } as TimeEntry;
        const values: Record<string, unknown> = { ...patch };
        if (action === "finalizar") {
          Object.assign(values, recalculated(draft, employee, settings));
          values['status'] = "finalizado";
        }
        const { error } = await supabase
          .from("time_entries")
          .update(values as never)
          .eq("id", entry.id);
        if (error) throw error;
      }
      toast.success("Registro efetuado.");
      await refetch();
      qc.invalidateQueries({ queryKey: ["entries"] });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não foi possível registrar.");
    } finally {
      setBusy(false);
    }
  }

  if (!employee) {
    return (
      <Shell nome={profileName} onSignOut={signOut}>
        <div className="panel p-6 text-center">
          <h2 className="font-display text-xl font-semibold">Cadastro pendente</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Seu usuário ainda não está vinculado a um colaborador. Peça ao administrador para
            vincular seu acesso na tela de Colaboradores.
          </p>
        </div>
      </Shell>
    );
  }

  const statusText =
    action === "iniciar"
      ? "Expediente não iniciado"
      : action === "retornar"
        ? "Em intervalo"
        : action === "concluido"
          ? "Expediente concluído"
          : "Expediente em andamento";

  const trabalhadoAgora = liveHours(entry ?? null);

  const Icon =
    action === "iniciar"
      ? Play
      : action === "intervalo"
        ? Coffee
        : action === "retornar"
          ? Undo2
          : Square;

  return (
    <Shell nome={profileName} onSignOut={signOut}>
      <section className="panel overflow-hidden">
        <div className="bg-primary px-5 py-4 text-primary-foreground">
          <p className="flex items-center gap-2 text-sm opacity-80">
            <CalendarDays className="size-4" />
            {fmtDateLong(new Date())}
          </p>
          <p className="mt-3 font-display text-2xl font-bold uppercase tracking-wide">
            {statusText}
          </p>
          {entry?.status && (
            <Badge variant="secondary" className="mt-2">
              {STATUS_LABEL[entry.status]}
            </Badge>
          )}
        </div>

        <div className="grid grid-cols-2 gap-px bg-border text-center">
          <Info label="Entrada" value={fmtTime(entry?.entrada)} />
          <Info label="Intervalo" value={fmtTime(entry?.intervalo_inicio)} />
          <Info label="Retorno" value={fmtTime(entry?.intervalo_fim)} />
          <Info label="Saída" value={fmtTime(entry?.saida)} />
        </div>

        <div className="space-y-4 p-5">
          <div className="flex items-baseline justify-between">
            <span className="label-caps">Tempo trabalhado</span>
            <span className="numeric font-display text-3xl font-bold">
              {fmtHours(trabalhadoAgora)}
            </span>
          </div>

          <Button
            size="lg"
            className="h-20 w-full text-lg font-semibold uppercase tracking-wide"
            variant={action === "concluido" ? "secondary" : "default"}
            disabled={busy || action === "concluido"}
            onClick={punch}
          >
            <Icon className="mr-3 size-6" />
            {ACTION_LABEL[action]}
          </Button>

          {entry && (
            <div className="grid gap-3">
              <PhotoCapture
                employeeId={employee.id}
                entryId={entry.id}
                tipo={action === "concluido" ? "fim" : "inicio"}
                onSaved={() => refetchPhotos()}
              />
              {photos.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {photos.map((p) => (
                    <PhotoThumb key={p.id} photo={p} />
                  ))}
                </div>
              )}
            </div>
          )}

          {entry?.saida && (
            <p className="text-center text-sm text-muted-foreground">
              Último registro: saída às {fmtTime(entry.saida)}
            </p>
          )}
        </div>
      </section>

      <Link
        to="/meus-registros"
        className="panel flex items-center justify-between px-5 py-4 text-sm font-medium"
      >
        <span className="flex items-center gap-2">
          <ClipboardList className="size-4" /> Meus registros
        </span>
        <span className="text-muted-foreground">ver histórico</span>
      </Link>
    </Shell>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-card px-3 py-4">
      <p className="label-caps">{label}</p>
      <p className="numeric mt-1 font-display text-xl font-semibold">{value}</p>
    </div>
  );
}

function liveHours(entry: TimeEntry | null): number {
  if (!entry?.entrada) return 0;
  const start = new Date(entry.entrada).getTime();
  const end = entry.saida ? new Date(entry.saida).getTime() : Date.now();
  let ms = end - start;
  const bs = entry.intervalo_inicio ? new Date(entry.intervalo_inicio).getTime() : null;
  const be = entry.intervalo_fim ? new Date(entry.intervalo_fim).getTime() : entry.saida ? null : Date.now();
  if (bs && be && be > bs) ms -= be - bs;
  return Math.max(0, ms) / 3_600_000;
}

export function Shell({
  children,
  nome,
  onSignOut,
}: {
  children: React.ReactNode;
  nome: string;
  onSignOut: () => void;
}) {
  return (
    <div className="min-h-screen bg-background pb-10">
      <header className="flex items-center justify-between border-b border-border bg-card px-5 py-4">
        <div>
          <p className="label-caps">Controle Operacional</p>
          <h1 className="font-display text-xl font-bold">Olá, {nome.split(" ")[0]}</h1>
        </div>
        <Button variant="ghost" size="icon" onClick={onSignOut} aria-label="Sair">
          <LogOut className="size-5" />
        </Button>
      </header>
      <main className="mx-auto flex max-w-lg flex-col gap-4 px-4 py-5">{children}</main>
    </div>
  );
}
