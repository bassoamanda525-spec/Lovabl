import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useEntries, useSettings } from "@/lib/queries";
import { entryTotals, STATUS_LABEL } from "@/lib/payroll";
import { fmtDate, fmtHours, fmtMoney, fmtTime } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Shell } from "./ponto";

export const Route = createFileRoute("/_authenticated/meus-registros")({
  head: () => ({
    meta: [
      { title: "Meus Registros — Controle Operacional" },
      { name: "description", content: "Histórico da sua jornada, horas extras e noturnas." },
      { property: "og:title", content: "Meus Registros — Controle Operacional" },
      { property: "og:description", content: "Histórico de ponto do colaborador." },
    ],
  }),
  component: MeusRegistros,
});

function MeusRegistros() {
  const { employee, profileName, signOut } = useAuth();
  const { data: settings } = useSettings();
  const { data: entries = [] } = useEntries({
    employeeId: employee?.id,
    enabled: !!employee?.id,
  });

  return (
    <Shell nome={profileName} onSignOut={signOut}>
      <Link to="/ponto" className="flex items-center gap-2 text-sm text-muted-foreground">
        <ArrowLeft className="size-4" /> Voltar ao ponto
      </Link>

      {entries.length === 0 && (
        <p className="panel p-5 text-sm text-muted-foreground">Nenhum registro ainda.</p>
      )}

      {entries.map((entry) => {
        const totals = employee && settings ? entryTotals(entry, employee, settings) : null;
        return (
          <article key={entry.id} className="panel p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold">{fmtDate(entry.data)}</h2>
              <Badge variant="outline">{STATUS_LABEL[entry.status]}</Badge>
            </div>
            <div className="mt-3 grid grid-cols-4 gap-2 text-center text-sm">
              <Cell label="Entrada" value={fmtTime(entry.entrada)} />
              <Cell label="Interv." value={fmtTime(entry.intervalo_inicio)} />
              <Cell label="Retorno" value={fmtTime(entry.intervalo_fim)} />
              <Cell label="Saída" value={fmtTime(entry.saida)} />
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border pt-3 text-center text-sm">
              <Cell label="Trabalhadas" value={fmtHours(entry.horas_trabalhadas)} />
              <Cell label="Extras" value={fmtHours(entry.horas_extras)} />
              <Cell label="Noturnas" value={fmtHours(entry.horas_noturnas)} />
            </div>
            {totals && (
              <p className="mt-3 flex justify-between border-t border-border pt-3 text-sm">
                <span className="label-caps">Valor do dia</span>
                <span className="numeric font-semibold">{fmtMoney(totals.total)}</span>
              </p>
            )}
          </article>
        );
      })}
    </Shell>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="label-caps">{label}</p>
      <p className="numeric font-medium">{value}</p>
    </div>
  );
}
