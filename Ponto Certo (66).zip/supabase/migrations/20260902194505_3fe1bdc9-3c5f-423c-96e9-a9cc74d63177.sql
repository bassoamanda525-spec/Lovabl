CREATE POLICY "comprovacoes_select" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'comprovacoes' AND (public.is_admin() OR (storage.foldername(name))[1] = public.current_employee_id()::text));
CREATE POLICY "comprovacoes_insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'comprovacoes' AND (public.is_admin() OR (storage.foldername(name))[1] = public.current_employee_id()::text));
CREATE POLICY "comprovacoes_delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'comprovacoes' AND public.is_admin());