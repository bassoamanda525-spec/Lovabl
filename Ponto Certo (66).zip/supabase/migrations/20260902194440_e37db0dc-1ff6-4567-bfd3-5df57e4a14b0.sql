-- SETTINGS
CREATE TABLE public.app_settings (
  id BOOLEAN PRIMARY KEY DEFAULT TRUE,
  jornada_diaria_horas NUMERIC NOT NULL DEFAULT 8,
  jornada_semanal_horas NUMERIC NOT NULL DEFAULT 44,
  hora_inicio_prevista TIME NOT NULL DEFAULT '08:00',
  hora_fim_prevista TIME NOT NULL DEFAULT '17:00',
  tolerancia_minutos INTEGER NOT NULL DEFAULT 10,
  valor_hora_extra NUMERIC NOT NULL DEFAULT 0,
  forma_calculo_hora_extra TEXT NOT NULL DEFAULT 'valor_fixo',
  percentual_hora_extra NUMERIC NOT NULL DEFAULT 50,
  noturno_inicio TIME NOT NULL DEFAULT '22:00',
  noturno_fim TIME NOT NULL DEFAULT '05:00',
  valor_hora_noturna NUMERIC NOT NULL DEFAULT 0,
  valor_vt NUMERIC NOT NULL DEFAULT 0,
  vt_padrao_ativo BOOLEAN NOT NULL DEFAULT FALSE,
  adicional_padrao NUMERIC NOT NULL DEFAULT 0,
  desconto_padrao NUMERIC NOT NULL DEFAULT 0,
  outros_custos_padrao NUMERIC NOT NULL DEFAULT 0,
  intervalo_descontado BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT app_settings_singleton CHECK (id)
);
GRANT SELECT, INSERT, UPDATE ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings_read" ON public.app_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "settings_admin_insert" ON public.app_settings FOR INSERT TO authenticated WITH CHECK (public.is_admin());
CREATE POLICY "settings_admin_update" ON public.app_settings FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER app_settings_updated_at BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
INSERT INTO public.app_settings (id) VALUES (TRUE);

-- EMPLOYEES
CREATE TABLE public.employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE,
  nome TEXT NOT NULL,
  documento TEXT,
  tipo public.employee_type NOT NULL DEFAULT 'diarista',
  valor_diaria NUMERIC,
  jornada_diaria_horas NUMERIC,
  valor_hora_extra NUMERIC,
  valor_hora_noturna NUMERIC,
  valor_vt NUMERIC,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  observacoes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.employees TO authenticated;
GRANT ALL ON public.employees TO service_role;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "employees_select" ON public.employees FOR SELECT TO authenticated
  USING (public.is_admin() OR user_id = auth.uid());
CREATE POLICY "employees_admin_write" ON public.employees FOR ALL TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.current_employee_id()
RETURNS UUID LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT id FROM public.employees WHERE user_id = auth.uid() LIMIT 1;
$$;
REVOKE ALL ON FUNCTION public.current_employee_id() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.current_employee_id() TO authenticated;

-- PERIODS
CREATE TABLE public.periods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nome TEXT NOT NULL,
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  status public.period_status NOT NULL DEFAULT 'aberto',
  fechado_em TIMESTAMPTZ,
  fechado_por UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.periods TO authenticated;
GRANT ALL ON public.periods TO service_role;
ALTER TABLE public.periods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "periods_read" ON public.periods FOR SELECT TO authenticated USING (true);
CREATE POLICY "periods_admin_write" ON public.periods FOR ALL TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE TRIGGER periods_updated_at BEFORE UPDATE ON public.periods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.date_is_locked(_data DATE)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.periods
    WHERE status = 'fechado' AND _data BETWEEN data_inicio AND data_fim
  );
$$;
REVOKE ALL ON FUNCTION public.date_is_locked(date) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.date_is_locked(date) TO authenticated;

-- TIME ENTRIES
CREATE TABLE public.time_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  data DATE NOT NULL,
  entrada TIMESTAMPTZ,
  intervalo_inicio TIMESTAMPTZ,
  intervalo_fim TIMESTAMPTZ,
  saida TIMESTAMPTZ,
  horas_trabalhadas NUMERIC NOT NULL DEFAULT 0,
  jornada_prevista NUMERIC NOT NULL DEFAULT 0,
  horas_extras NUMERIC NOT NULL DEFAULT 0,
  horas_noturnas NUMERIC NOT NULL DEFAULT 0,
  horas_extras_manual BOOLEAN NOT NULL DEFAULT FALSE,
  horas_noturnas_manual BOOLEAN NOT NULL DEFAULT FALSE,
  vt_aplicado BOOLEAN NOT NULL DEFAULT FALSE,
  vt_valor NUMERIC,
  adicionais NUMERIC NOT NULL DEFAULT 0,
  descontos NUMERIC NOT NULL DEFAULT 0,
  outros_custos NUMERIC NOT NULL DEFAULT 0,
  observacoes TEXT,
  status public.entry_status NOT NULL DEFAULT 'em_andamento',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (employee_id, data)
);
CREATE INDEX time_entries_data_idx ON public.time_entries(data);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.time_entries TO authenticated;
GRANT ALL ON public.time_entries TO service_role;
ALTER TABLE public.time_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "entries_select" ON public.time_entries FOR SELECT TO authenticated
  USING (public.is_admin() OR employee_id = public.current_employee_id());
CREATE POLICY "entries_admin_all" ON public.time_entries FOR ALL TO authenticated
  USING (public.is_admin()) WITH CHECK (public.is_admin());
CREATE POLICY "entries_own_insert" ON public.time_entries FOR INSERT TO authenticated
  WITH CHECK (employee_id = public.current_employee_id() AND NOT public.date_is_locked(data));
CREATE POLICY "entries_own_update" ON public.time_entries FOR UPDATE TO authenticated
  USING (employee_id = public.current_employee_id() AND status <> 'aprovado' AND NOT public.date_is_locked(data))
  WITH CHECK (employee_id = public.current_employee_id() AND NOT public.date_is_locked(data));
CREATE TRIGGER time_entries_updated_at BEFORE UPDATE ON public.time_entries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- PHOTOS
CREATE TABLE public.time_entry_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  time_entry_id UUID NOT NULL REFERENCES public.time_entries(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  tipo public.photo_kind NOT NULL,
  storage_path TEXT NOT NULL,
  registrado_em TIMESTAMPTZ NOT NULL DEFAULT now(),
  latitude NUMERIC,
  longitude NUMERIC,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, DELETE ON public.time_entry_photos TO authenticated;
GRANT ALL ON public.time_entry_photos TO service_role;
ALTER TABLE public.time_entry_photos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "photos_select" ON public.time_entry_photos FOR SELECT TO authenticated
  USING (public.is_admin() OR employee_id = public.current_employee_id());
CREATE POLICY "photos_insert" ON public.time_entry_photos FOR INSERT TO authenticated
  WITH CHECK (public.is_admin() OR employee_id = public.current_employee_id());
CREATE POLICY "photos_admin_delete" ON public.time_entry_photos FOR DELETE TO authenticated
  USING (public.is_admin());

-- ADJUSTMENTS
CREATE TABLE public.time_entry_adjustments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  time_entry_id UUID NOT NULL REFERENCES public.time_entries(id) ON DELETE CASCADE,
  campo TEXT NOT NULL,
  valor_anterior TEXT,
  valor_novo TEXT,
  justificativa TEXT NOT NULL,
  alterado_por UUID NOT NULL DEFAULT auth.uid(),
  alterado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.time_entry_adjustments TO authenticated;
GRANT ALL ON public.time_entry_adjustments TO service_role;
ALTER TABLE public.time_entry_adjustments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "adjustments_select" ON public.time_entry_adjustments FOR SELECT TO authenticated
  USING (public.is_admin() OR EXISTS (
    SELECT 1 FROM public.time_entries te
    WHERE te.id = time_entry_id AND te.employee_id = public.current_employee_id()
  ));
CREATE POLICY "adjustments_admin_insert" ON public.time_entry_adjustments FOR INSERT TO authenticated
  WITH CHECK (public.is_admin() AND alterado_por = auth.uid());